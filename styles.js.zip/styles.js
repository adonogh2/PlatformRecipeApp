// styles.js
import { StyleSheet } from 'react-native';

export const globalStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 20,
  },
  button: {
    marginTop: 10,
    backgroundColor: '#556B2F', 
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    justifyContent: 'center',
    alignItems: 'center',
  },
  // view recipes button on home screen
  recipeButtonContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginBottom: 20, // Adjust to move the button further down
  },
  recipeButton: {
    backgroundColor: '#D6A8CB', 
    padding: 20,
    borderRadius: 10,
    marginLeft: 9,
  },
  // view recipes button text on the home screen 
  buttonText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'white', 
    textAlign: 'center',
    fontFamily: 'Times New Roman',
  },
  fetchIngredientsButton: {
    marginTop: 10,
    backgroundColor: '#556B2F', // Olive Green color
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
});

export const recipeStyles = StyleSheet.create({
  recipeItem: {
    marginBottom: 20,
    backgroundColor: '#F5DEB3', // Sand color
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  
  recipeDetails: {
    padding: 16,
    backgroundColor: 'lightgray', // Set the background color for recipe details
    fontFamily: 'Times New Roman',
  },
  recipeName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    fontFamily: 'Times New Roman',
  },
  recipeDescription: {
    fontSize: 16,
    color: 'black',
    marginBottom: 10,
    fontFamily: 'Times New Roman',
  },
  fetchIngredientsButton: {
    marginTop: 10,
    backgroundColor: '#556B2F', // Olive Green color
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  // Add a new style for ingredient text
  ingredientText: {
    fontSize: 20,
    marginBottom: 4,
    fontFamily: 'Times New Roman',
    color: 'darkgreen',
  },
});