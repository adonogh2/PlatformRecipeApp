import { StyleSheet } from 'react-native';

export const globalStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#D6A8CB', // mauve color for the background
    padding: 20,
  },
  button: {
    marginTop: 10,
    backgroundColor: '#D6A8CB', // mauve color for buttons
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    justifyContent: 'center',
    alignItems: 'center',
  },
  recipeButtonContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginBottom: 20,
  },
  // view recipes button on home screen 
  recipeButton: {
    backgroundColor: '#D6A8CB', // mauve
    padding: 20,
    borderRadius: 10,
    marginHorizontal: 0, // adjust for symmetric horizontal padding
    marginBottom: 10,
  },
  // text for view recipies 
  buttonText: {
    fontSize: 30, 
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    fontFamily: 'Times New Roman', 
  },
  fetchIngredientsButton: {
    marginTop: 10,
    backgroundColor: '#D6A8CB', // mauve
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
});

export const recipeStyles = StyleSheet.create({
  recipeItem: {
    marginBottom: 20,
    backgroundColor: '#D6A8CB', //mauve
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  recipeDetails: {
    padding: 16,
    backgroundColor: 'white', // boxes on recipes.js
    fontFamily: 'Times New Roman', 
  },
  // recipe names 
  recipeName: {
    fontSize: 24, 
    fontWeight: 'bold',
    marginBottom: 5,
    fontFamily: 'Times New Roman', 
    color: '#black', //title color for recipes 
  },
  // Recipe Description on Recipes.js
  recipeDescription: {
    fontSize: 16,
    color: 'black',
    marginBottom: 10,
    fontFamily: 'Times New Roman', 
  },
  ingredientText: {
    fontSize: 18, // Adjusted for readability
    marginBottom: 4,
    fontFamily: 'Times New Roman', // Consistent font
    color: 'black',
  },
});
