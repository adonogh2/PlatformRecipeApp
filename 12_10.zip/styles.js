// styles.js
import { StyleSheet } from 'react-native';

export const globalStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 20,
  },
  button: {
    marginTop: 10,
    backgroundColor: '#556B2F', // Tomato color
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    justifyContent: 'center',
    alignItems: 'center',
  },
  recipeButtonContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginBottom: 185, // Adjust the marginBottom to move the button further down
  },
  recipeButton: {
    backgroundColor: 'gray', // Set the background color to black
    padding: 20,
    borderRadius: 10,
    marginLeft: 9,
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white', // Set the text color to white
    textAlign: 'center',
    fontFamily: 'Times New Roman',
  },
  fetchIngredientsButton: {
    marginTop: 10,
    backgroundColor: '#556B2F', // Olive Green color
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
});

export const recipeStyles = StyleSheet.create({
  recipeItem: {
    marginBottom: 20,
    backgroundColor: '#FFF',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  
  recipeDetails: {
    padding: 16,
    backgroundColor: 'lightgray', // Set the background color for recipe details
    fontFamily: 'Times New Roman',
  },
  recipeName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    fontFamily: 'Times New Roman',
  },
  recipeDescription: {
    fontSize: 16,
    color: 'black',
    marginBottom: 10,
    fontFamily: 'Times New Roman',
  },
  fetchIngredientsButton: {
    marginTop: 10,
    backgroundColor: '#556B2F', // Olive Green color
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  // Add a new style for ingredient text
  ingredientText: {
    fontSize: 14,
    marginBottom: 4,
    fontFamily: 'Times New Roman',
    color: 'darkgreen', // You can adjust the color as needed
  },
});
