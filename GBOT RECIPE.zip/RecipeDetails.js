import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, Button, Alert } from 'react-native';

const RecipeDetails = ({ route }) => {
  const { item } = route.params;
  const [recipeDetails, setRecipeDetails] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRecipeDetails = async () => {
      const url = 'https://tasty.p.rapidapi.com/recipes/get-more-info?id=8138';
        const options = {
	      method: 'GET',
	      headers: {
		'X-RapidAPI-Key': '6b023667b8mshe1778ebdd791a80p1a1efejsnd2b7c4d24142',
		'X-RapidAPI-Host': 'tasty.p.rapidapi.com'
	}
};

      try {
        const response = await fetch(url, options);
        const result = await response.json(); // Parse response as JSON
        console.log(result);

        setRecipeDetails(result);
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
      }
    };

    fetchRecipeDetails();
  }, [item.id]);

  const fetchIngredients = async () => {
    const url = 'https://tasty.p.rapidapi.com/recipes/auto-complete?prefix=chicken%20soup';
    const options = {
	  method: 'GET',
	  headers: {
		'X-RapidAPI-Key': '6b023667b8mshe1778ebdd791a80p1a1efejsnd2b7c4d24142',
		'X-RapidAPI-Host': 'tasty.p.rapidapi.com'
	}
};

    try {
      const response = await fetch(ingredientUrl, ingredientOptions);
      const result = await response.json(); // Parse response as JSON
      console.log(result);

      if (Array.isArray(result)) {
        // Display ingredients in an alert
        Alert.alert('Ingredients', result.map((ingredient) => ingredient.name).join('\n'));
      } else {
        console.error('Unexpected API response format:', result);
      }
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) {
    return <ActivityIndicator size="large" />;
  }

  return (
    <View>
      <Text>{item.name}</Text>
      {/* Display other recipe details and ingredients here */}
      {recipeDetails && (
        <View>
          {/* Display additional details from the recipeDetails object */}
          <Text>{recipeDetails.description}</Text>
          {/* Add more Text components or custom styling as needed */}
          <Button title="Fetch Ingredients" onPress={fetchIngredients} />
        </View>
      )}
    </View>
  );
};

export default RecipeDetails;
