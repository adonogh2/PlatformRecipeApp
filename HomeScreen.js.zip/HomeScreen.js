// HomeScreen.js

import React from 'react';
import { View, TouchableOpacity, ImageBackground, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { globalStyles } from './styles';

const HomeScreen = () => {
  const navigation = useNavigation();
  const backgroundImage = require('./GBOTBackground.png');

  // styles for home button are stored in styles.js 
  
  return (
    <View style={globalStyles.container}>
      <ImageBackground source={backgroundImage} style={globalStyles.backgroundImage}>
        <View style={globalStyles.recipeButtonContainer}>
          <TouchableOpacity
            style={globalStyles.recipeButton}
            onPress={() => navigation.navigate('Recipes')}
          >
            <Text style={globalStyles.buttonText}>View Recipies</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </View>
  );
};

export default HomeScreen;
