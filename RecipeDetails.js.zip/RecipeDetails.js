import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, Button, ScrollView } from 'react-native';
import { globalStyles, recipeStyles } from './styles'; // Add this import statement


const RecipeDetails = ({ route }) => {
  const { item } = route.params;
  const [recipeDetails, setRecipeDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [ingredientDetails, setIngredientDetails] = useState([]);

  useEffect(() => {
    const fetchRecipeDetails = async () => {
      const url = `https://tasty.p.rapidapi.com/recipes/get-more-info?id=${item.id}`;
      const options = {
        method: 'GET',
        headers: {
          'X-RapidAPI-Key': '6b023667b8mshe1778ebdd791a80p1a1efejsnd2b7c4d24142',
          'X-RapidAPI-Host': 'tasty.p.rapidapi.com',
        },
      };

      try {
        const response = await fetch(url, options);
        const result = await response.json();

        setRecipeDetails(result);
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
      }
    };

    fetchRecipeDetails();
  }, [item.id]);

  const fetchIngredients = async () => {
    const url = `https://tasty.p.rapidapi.com/recipes/list?from=0&size=20&tags=under_30_minutes`;
    const options = {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': '6b023667b8mshe1778ebdd791a80p1a1efejsnd2b7c4d24142',
        'X-RapidAPI-Host': 'tasty.p.rapidapi.com',
      },
    };
  
    try {
      const response = await fetch(url, options);
      const result = await response.json();
  
      if (result.results && Array.isArray(result.results)) {
        const currentRecipeIngredients = result.results
          .filter(recipe => recipe.id === item.id)
          .map(recipe => {
            if (recipe.sections && Array.isArray(recipe.sections)) {
              const ingredientSection = recipe.sections.find(section => section.components);
  
              if (ingredientSection && Array.isArray(ingredientSection.components)) {
                return ingredientSection.components.map(component => ({
                  recipe: recipe.name,
                  ingredient: component.ingredient,
                }));
              } else {
                console.error('No ingredients found in the API response.');
              }
            } else {
              console.error('No sections found in the API response.');
            }
          })
          .flat();
  
        setIngredientDetails(currentRecipeIngredients);
      } else {
        console.error('Unexpected API response format:', result);
      }
    } catch (error) {
      console.error('Error fetching ingredients:', error);
    }
  };
  
  if (loading) {
    return <ActivityIndicator size="large" />;
  }

  return (
    <ScrollView style={globalStyles.container}>
      <Text style={recipeStyles.recipeName}>{item.name}</Text>
      {recipeDetails && (
        <View>
          <Text>{recipeDetails.description}</Text>
          <Button
            title="Fetch Ingredients"
            onPress={fetchIngredients}
            style={globalStyles.fetchIngredientsButton}
          />
          <ScrollView>
            {ingredientDetails.map((detail, index) => (
              <Text key={index}>{`Recipe: ${detail.recipe}, Ingredient: ${detail.ingredient.display_singular}`}</Text>
            ))}
          </ScrollView>
        </View>
      )}
    </ScrollView>
  );
};

export default RecipeDetails;
