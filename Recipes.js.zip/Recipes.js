import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const Recipes = () => {
  const navigation = useNavigation();
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    // Fetch data from the Tasty API when the component mounts
    getRecipesFromApi();
  }, []);

  async function getRecipesFromApi() {
    const url = 'https://tasty.p.rapidapi.com/recipes/list?from=0&size=20&tags=under_30_minutes';
    const options = {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': '6b023667b8mshe1778ebdd791a80p1a1efejsnd2b7c4d24142',
        'X-RapidAPI-Host': 'tasty.p.rapidapi.com',
      },
    };

    try {
      const response = await fetch(url, options);
      const result = await response.json(); // Parse response as JSON
      console.log(result);

      // Check if 'results' array exists and has at least one item
      if (result.results && result.results.length > 0) {
        setRecipes(result.results);
      } else {
        console.error('Invalid Tasty API response:', result);
      }
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={recipes}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('RecipeDetails', { item })}>
            <View>
              <Text>{item.name}</Text>
              {/* Add more Text components or custom styling as needed */}
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default Recipes;
