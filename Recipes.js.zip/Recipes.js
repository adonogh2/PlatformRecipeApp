import React, { useState, useEffect } from 'react';
import { View, FlatList, TouchableOpacity, Text, ActivityIndicator, StyleSheet, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { globalStyles, recipeStyles } from './styles';

const Recipes = () => {
  const navigation = useNavigation();
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    // get recipes
    getRecipesFromApi();
  }, []);

  async function getRecipesFromApi() {
    const url = 'https://tasty.p.rapidapi.com/recipes/list?from=0&size=20&tags=under_30_minutes';
    const options = {
      method: 'GET',
      // recipe and ingredient api 
      headers: {
        'X-RapidAPI-Key': '501bd13253msh361b35f81415f0ep14ff8cjsna1185e732d8c',
        'X-RapidAPI-Host': 'tasty.p.rapidapi.com',
      },
    };

    // fetching recipes to be displayed on the home screen 
    try {
      const response = await fetch(url, options);
      const result = await response.json();

      if (result.results && result.results.length > 0) {
        // update the state with newly fetched recipes
        setRecipes(result.results);
      } else {
        // log an error message if the API response is invalid
        console.error('Invalid Tasty API response:', result);
      }
    } catch (error) {
      // log an error if there is an issue with the API request
      console.error(error);
    }
  }

  return (
    <View style={globalStyles.container}>
      {recipes.length === 0 ? (
        // loading indicator if recipes are still being fetched
        <ActivityIndicator size="large" />
      ) : (
        // FlatList to render the recipes
        <FlatList
          data={recipes}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            // TouchableOpacity to make each recipe item page
            <TouchableOpacity
              style={recipeStyles.recipeItem}
              onPress={() => navigation.navigate('RecipeDetails', { item })}
            >
              <View style={recipeStyles.recipeDetails}>
                {/* Display recipe name and description */}
                <Text style={recipeStyles.recipeName}>{item.name}</Text>
                <Text style={recipeStyles.recipeDescription}>{item.description}</Text>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

export default Recipes;
