import React, { useState, useEffect } from 'react';
import { View, FlatList, TouchableOpacity, Text, ActivityIndicator, StyleSheet, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { globalStyles, recipeStyles } from './styles';

const Recipes = () => {
  const navigation = useNavigation();
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    getRecipesFromApi();
  }, []);

  async function getRecipesFromApi() {
    const url = 'https://tasty.p.rapidapi.com/recipes/list?from=0&size=20&tags=under_30_minutes';
    const options = {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': '6b023667b8mshe1778ebdd791a80p1a1efejsnd2b7c4d24142',
        'X-RapidAPI-Host': 'tasty.p.rapidapi.com',
      },
    };

    try {
      const response = await fetch(url, options);
      const result = await response.json();

      if (result.results && result.results.length > 0) {
        setRecipes(result.results);
      } else {
        console.error('Invalid Tasty API response:', result);
      }
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <View style={globalStyles.container}>

      {recipes.length === 0 ? (
        <ActivityIndicator size="large" />
      ) : (
        <FlatList
          data={recipes}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={recipeStyles.recipeItem}
              onPress={() => navigation.navigate('RecipeDetails', { item })}
            >
              {/* Include an image if available */}
              {item.thumbnail && (
                <Image source={{ uri: item.thumbnail }} style={recipeStyles.recipeImage} />
              )}

              <View style={recipeStyles.recipeDetails}>
                <Text style={recipeStyles.recipeName}>{item.name}</Text>
                <Text style={recipeStyles.recipeDescription}>{item.description}</Text>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

export default Recipes;
